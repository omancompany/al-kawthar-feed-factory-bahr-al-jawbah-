import factoryBannerImg from './images/factory_banner_1789339031433.jpg';
import pinkFeedBagImg from './images/pink_feed_bag_1789339044871.jpg';
import feedProductionImg from './images/feed_production_1789339057321.jpg';
import feedSupplyLogisticsImg from './images/feed_supply_logistics_1789342866518.jpg';
import feedQualityLabImg from './images/feed_quality_gulf_1789343226179.jpg';

export const ASSETS = {
  factoryBanner: factoryBannerImg,
  pinkFeedBag: pinkFeedBagImg,
  feedProduction: feedProductionImg,
  feedSupplyLogistics: feedSupplyLogisticsImg,
  feedQualityLab: feedQualityLabImg,
};

