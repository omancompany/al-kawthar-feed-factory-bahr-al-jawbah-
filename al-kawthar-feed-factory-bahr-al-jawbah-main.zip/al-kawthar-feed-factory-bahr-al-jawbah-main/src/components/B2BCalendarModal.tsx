import React, { useState } from 'react';
import { translations } from '../translations';
import { Language, ConsultationFormData } from '../types';
import {
  X,
  CalendarCheck,
  Building2,
  Clock,
  Phone,
  MessageCircle,
  CheckCircle2,
  Send,
} from 'lucide-react';

interface B2BCalendarModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const B2BCalendarModal: React.FC<B2BCalendarModalProps> = ({
  isOpen,
  onClose,
  lang,
}) => {
  const t = translations[lang];

  const [form, setForm] = useState<ConsultationFormData>({
    fullName: '',
    companyName: '',
    phone: '',
    preferredDate: '',
    preferredTime: 'صباحاً (08:00 - 12:00)',
    topic: 'عقود توريد دورية للمجترات',
    notes: '',
  });

  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);

    const subject = encodeURIComponent(
      `طلب موعد استشارة وتوريد: ${form.fullName || 'عميل'} - ${form.companyName || 'مزرعة/جهة'}`
    );
    const body = encodeURIComponent(
      `السلام عليكم ورحمة الله وبركاته،\n\n` +
      `طلب موعد استشارة وتوريد أعلاف الكوثر:\n` +
      `• الاسم: ${form.fullName}\n` +
      `• المنشأة / المزرعة: ${form.companyName}\n` +
      `• رقم التواصل: ${form.phone}\n` +
      `• التاريخ المفضل: ${form.preferredDate || 'في أقرب وقت'}\n` +
      `• الفترة: ${form.preferredTime}\n` +
      `• الموضوع: ${form.topic}\n` +
      `• ملاحظات: ${form.notes || 'لا توجد'}\n\n` +
      `يرجى تأكيد الموعد المناسب.`
    );
    setTimeout(() => {
      window.location.href = `mailto:alkawthercattlefeed@gmail.com?subject=${subject}&body=${body}`;
    }, 400);
  };

  return (
    <div
      id="b2b-calendar-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm animate-fadeIn"
    >
      <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-[#EBDCF0] overflow-hidden text-start">
        {/* Header */}
        <div className="flex items-center justify-between p-5 sm:p-6 border-b border-[#EBDCF0] bg-gradient-to-r from-[#FAF0FA] to-[#FDF5F8]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white text-[#8E4A96] flex items-center justify-center shrink-0 border border-[#EBDCF0] shadow-2xs">
              <CalendarCheck className="w-5 h-5 text-[#8E4A96]" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-[#3B1C48] heading-font">
                {t.b2b.cta}
              </h3>
              <p className="text-xs text-[#5A4565]">
                {lang === 'ar' ? 'فريق مبيعات مصنع بحار الجوبة' : 'Bahar Al-Jouba Sales Advisory Team'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-[#8C7698] hover:text-[#3B1C48] hover:bg-white/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6">
          {submitted ? (
            <div className="p-6 rounded-2xl bg-[#FAF4FC] border border-[#EBDCF0] text-center space-y-4">
              <CheckCircle2 className="w-10 h-10 text-[#D9487C] mx-auto" />
              <h4 className="text-lg font-bold text-[#3B1C48]">
                {lang === 'ar' ? 'تم حجز موعد المبيعات بنجاح' : 'Consultation Scheduled Successfully'}
              </h4>
              <p className="text-sm text-[#5A4565]">
                {lang === 'ar'
                  ? 'تم استلام بياناتك. سيتصل بك مستشار المبيعات لتأكيد التوقيت ومناقشة تفاصيل التوريد.'
                  : 'Your request has been logged. Our commercial sales advisor will call to confirm schedule.'}
              </p>
              <div className="pt-2 flex justify-center gap-3">
                <button
                  onClick={onClose}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#E13B6B] to-[#D8265D] hover:from-[#D8265D] hover:to-[#B8194B] text-white font-bold text-xs sm:text-sm shadow-xs transition-colors"
                >
                  {lang === 'ar' ? 'تم، إغلاق النافذة' : 'Done, Close Window'}
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-[#5A4565] mb-1">
                    {t.contact.fields.fullName} <span className="text-[#D9487C]">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={form.fullName}
                    onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                    placeholder={t.contact.fields.fullNamePlaceholder}
                    className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-[#E5D7E8] focus:border-[#8E4A96] focus:ring-2 focus:ring-purple-100 outline-none transition-all text-[#3B1C48] bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#5A4565] mb-1">
                    {t.contact.fields.companyName} <span className="text-[#D9487C]">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={form.companyName}
                    onChange={(e) => setForm({ ...form, companyName: e.target.value })}
                    placeholder={t.contact.fields.companyNamePlaceholder}
                    className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-[#E5D7E8] focus:border-[#8E4A96] focus:ring-2 focus:ring-purple-100 outline-none transition-all text-[#3B1C48] bg-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-[#5A4565] mb-1">
                    {t.contact.fields.phone} <span className="text-[#D9487C]">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                    placeholder="+968 XXXXXXXX"
                    className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-[#E5D7E8] focus:border-[#8E4A96] focus:ring-2 focus:ring-purple-100 outline-none transition-all text-[#3B1C48] bg-white"
                    dir="ltr"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#5A4565] mb-1">
                    {lang === 'ar' ? 'التاريخ المفضل للموعد' : 'Preferred Date'}
                  </label>
                  <input
                    type="date"
                    value={form.preferredDate}
                    onChange={(e) => setForm({ ...form, preferredDate: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-[#E5D7E8] focus:border-[#8E4A96] focus:ring-2 focus:ring-purple-100 outline-none transition-all text-[#3B1C48] bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#5A4565] mb-1">
                  {lang === 'ar' ? 'فترة التواصل المفضلة' : 'Preferred Time'}
                </label>
                <select
                  value={form.preferredTime}
                  onChange={(e) => setForm({ ...form, preferredTime: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-[#E5D7E8] focus:border-[#8E4A96] focus:ring-2 focus:ring-purple-100 outline-none transition-all text-[#3B1C48] bg-white"
                >
                  <option value="صباحاً (08:00 - 12:00)">
                    {lang === 'ar' ? 'صباحاً (08:00 - 12:00)' : 'Morning (08:00 - 12:00)'}
                  </option>
                  <option value="ظهراً (12:00 - 15:00)">
                    {lang === 'ar' ? 'ظهراً (12:00 - 15:00)' : 'Afternoon (12:00 - 15:00)'}
                  </option>
                  <option value="مساءً (16:00 - 20:00)">
                    {lang === 'ar' ? 'مساءً (16:00 - 20:00)' : 'Evening (16:00 - 20:00)'}
                  </option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#5A4565] mb-1">
                  {lang === 'ar' ? 'ملاحظات إضافية أو متطلبات خاصة' : 'Additional Notes'}
                </label>
                <textarea
                  rows={3}
                  value={form.notes}
                  onChange={(e) => setForm({ ...form, notes: e.target.value })}
                  placeholder={
                    lang === 'ar'
                      ? 'حدد موقع مزرعتك أو استفسارك حول الكميات المطلوبة...'
                      : 'Specify location or volume needs...'
                  }
                  className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-[#E5D7E8] focus:border-[#8E4A96] focus:ring-2 focus:ring-purple-100 outline-none transition-all text-[#3B1C48] bg-white resize-y"
                />
              </div>

              <div className="pt-3 flex flex-col sm:flex-row gap-3">
                <button
                  type="submit"
                  className="w-full py-3 px-5 rounded-xl font-bold text-sm text-white bg-gradient-to-r from-[#E13B6B] to-[#D8265D] hover:from-[#D8265D] hover:to-[#B8194B] shadow-md shadow-pink-200/50 transition-all flex items-center justify-center gap-2"
                >
                  <Send className="w-4 h-4 text-white" />
                  <span>{lang === 'ar' ? 'تأكيد إرسال طلب الموعد' : 'Confirm Consultation Booking'}</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
